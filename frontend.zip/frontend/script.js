const API_URL = 'http://localhost:8000/products/';

async function fetchProducts() {
    const response = await fetch(API_URL);
    const products = await response.json();
    displayProducts(products);
}

function displayProducts(products) {
    const productList = document.getElementById('productList');
    productList.innerHTML = '';
    products.forEach(product => {
        const div = document.createElement('div');
        div.className = 'product-item';
        div.innerHTML = `
            <div>
                <strong>${product.name}</strong><br>
                Price: $${product.price} | Quantity: ${product.quantity}
            </div>
            <div>
                <button onclick="viewProduct(${product.id})">View</button>
                <button onclick="editProduct(${product.id})">Edit</button>
                <button onclick="deleteProduct(${product.id})">Delete</button>
            </div>
        `;
        productList.appendChild(div);
    });
}

async function filterProducts() {
    const filter = document.getElementById('filterInput').value.toLowerCase();
    const response = await fetch(API_URL);
    let products = await response.json();
    products = products.filter(product => product.name.toLowerCase().includes(filter));
    displayProducts(products);
}

async function viewProduct(id) {
    const response = await fetch(`${API_URL}${id}`);
    if (response.ok) {
        const product = await response.json();
        alert(`Name: ${product.name}\nDescription: ${product.description || 'N/A'}\nPrice: $${product.price}\nQuantity: ${product.quantity}`);
    } else {
        alert('Product not found');
    }
}

async function editProduct(id) {
    const response = await fetch(`${API_URL}${id}`);
    if (response.ok) {
        const product = await response.json();
        document.getElementById('editId').value = product.id;
        document.getElementById('editName').value = product.name;
        document.getElementById('editDescription').value = product.description || '';
        document.getElementById('editPrice').value = product.price;
        document.getElementById('editQuantity').value = product.quantity;
        document.getElementById('editProductForm').style.display = 'block';
        document.getElementById('addProductForm').style.display = 'none';
    } else {
        alert('Product not found');
    }
}

function cancelEdit() {
    document.getElementById('editProductForm').style.display = 'none';
    document.getElementById('addProductForm').style.display = 'block';
}

async function deleteProduct(id) {
    if (confirm('Are you sure you want to delete this product?')) {
        const response = await fetch(`${API_URL}${id}`, { method: 'DELETE' });
        if (response.ok) {
            fetchProducts();
        } else {
            alert('Failed to delete product');
        }
    }
}

document.getElementById('addProductForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const product = {
        name: document.getElementById('addName').value,
        description: document.getElementById('addDescription').value || null,
        price: parseFloat(document.getElementById('addPrice').value),
        quantity: parseInt(document.getElementById('addQuantity').value)
    };
    const response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(product)
    });
    if (response.ok) {
        document.getElementById('addProductForm').reset();
        fetchProducts();
    } else {
        alert('Failed to add product');
    }
});

document.getElementById('editProductForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('editId').value;
    const product = {
        name: document.getElementById('editName').value,
        description: document.getElementById('editDescription').value || null,
        price: parseFloat(document.getElementById('editPrice').value),
        quantity: parseInt(document.getElementById('editQuantity').value)
    };
    const response = await fetch(`${API_URL}${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(product)
    });
    if (response.ok) {
        document.getElementById('editProductForm').style.display = 'none';
        document.getElementById('addProductForm').style.display = 'block';
        fetchProducts();
    } else {
        alert('Failed to update product');
    }
});

fetchProducts();